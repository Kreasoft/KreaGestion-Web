@echo off
cd /d "%~dp0"
start "" "AgenteImpresion.exe"
